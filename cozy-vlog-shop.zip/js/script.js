
document.getElementById('themeToggle')?.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});

// Load cart from localStorage
let cart = JSON.parse(localStorage.getItem('cart')) || [];
const cartItemsContainer = document.getElementById('cart-items');
const cartTotal = document.getElementById('cart-total');

function addToCart(productName, price) {
  cart.push({ name: productName, price: parseFloat(price) });
  saveCart();
  updateCartDisplay();
}

function updateCartDisplay() {
  if (!cartItemsContainer || !cartTotal) return;
  cartItemsContainer.innerHTML = '';
  let total = 0;
  cart.forEach((item, index) => {
    const div = document.createElement('div');
    div.innerHTML = `<p>${item.name} - $${item.price.toFixed(2)} <button onclick="removeFromCart(${index})">Remove</button></p>`;
    cartItemsContainer.appendChild(div);
    total += item.price;
  });
  cartTotal.textContent = total.toFixed(2);
}

function removeFromCart(index) {
  cart.splice(index, 1);
  saveCart();
  updateCartDisplay();
}

function saveCart() {
  localStorage.setItem('cart', JSON.stringify(cart));
}

function checkout() {
  alert('Thank you for your purchase!');
  cart = [];
  saveCart();
  updateCartDisplay();
}

// Calendar setup
function createCalendar() {
  const calendarContainer = document.getElementById('event-calendar');
  if (!calendarContainer) return;

  const today = new Date();
  let calendarHTML = '<h3>Upcoming Events</h3><ul>';
  calendarHTML += `<li>${today.toDateString()}: Virtual Candle Workshop</li>`;
  calendarHTML += `<li>${new Date(today.getTime() + 7 * 86400000).toDateString()}: Pop-Up Market</li>`;
  calendarHTML += '</ul>';
  calendarContainer.innerHTML = calendarHTML;
}

createCalendar();
updateCartDisplay();
